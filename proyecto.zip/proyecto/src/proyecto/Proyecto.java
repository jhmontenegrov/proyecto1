package proyecto;

public class Proyecto {

    public static void main(String[] args) {
        
    }
}