/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

/**
 *
 * @author 202
 */
public class operaciones {
    /**
     *Descripción de laclase:
     * @param x recibe un valor de tipo double que debe digitar el cliente
     * @param z Es un valor de tipo dulbe que el usuario debe ingresar.
     * @return
     */
    public static double sumar(double x, double z)
    { 
    double y;
    y=x+z;
    return y;
    }
    /**
     * 
     * @param x recibe un valor double ingresado por el usuario
     * @param z el valor ingresado debe ser de tipo double
     * @return 
     */
    public static double restar(double x, double z)
    { 
    double y;
    y=x-z;
    return y;
    }
    /**
     * 
     * @param x 
     * @param z
     * @return 
     */
    public static double multiplicar(double x, double z)
    { 
    double y;
    y=x*z;
    return y;
    }
    /**
     * 
     * @param x
     * @param z
     * @return 
     */
    public static double dividir(double x, double z)
    { 
    double y;
    y=x/z;
    return y;
    }

}
